# Integration Handoff

## Scope
- Existing Android app only; preserve `app/src/main/assets/www/schedule2.0.html`.
- No backend, Azure services, REST API, database, migration, or third-party packager.
- No seed data or durable Todo persistence.
- Integration is validation of the handwritten local Java Activity/WebView host, not live-data wiring.

## Backend
- Project folder: none
- Run/build: from repository root, `.\gradlew.bat testDebugUnitTest assembleDebug`
- Port / health endpoint: none

## Frontend
- Project folder: `app/src/main/assets/www/`
- Entry file: `schedule2.0.html` (loaded from `file:///android_asset/www/schedule2.0.html`)
- Build: `.\gradlew.bat assembleDebug` from repository root; no separate frontend build.
- Dev command: none
- API seam / mock files: none; keep the page self-contained and unchanged.
- Native bridge: `AndroidBridge.showToast(message)`, `AndroidBridge.vibrate(milliseconds)`.

## Routes
- HTTP routes: none. The JavaScript bridge is local WebView-to-native IPC, not an API.

## Database
- Type / migration tool / directory / connection variables: none
- Seed data: explicitly none

## Shared Types and Services
- Shared package / import alias: none
- Service: `TodoList Android App` — Essential
- Enhancement services: none
