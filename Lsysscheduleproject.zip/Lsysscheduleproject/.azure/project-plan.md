# Project Plan

**Status**: Awaiting Integration
**Created**: 2026-10-26
**Mode**: AUGMENT

---

## 1. Project Overview

**Goal**: Extend the existing Android Studio project into a Java Activity/WebView host for the supplied Todo page at `app/src/main/assets/www/schedule2.0.html`. Preserve its current HTML/CSS/JavaScript UI, load it locally, and retain its JavaScript calls to native Toast and vibration. Android Back should navigate WebView history before leaving the Activity. The project is designed so that every module is independently testable.

**App Type**: Android native app with an embedded local WebView frontend and no backend (derived from the single Android app service)

**API Login**: No

**Mode**: AUGMENT

**Deployment Plan**: No deployment plan found

**Workspace evidence and scope boundary**:
- The workspace contains an Android Gradle app and `app/src/main/java/com/example/lsysscheduleproject/MainActivity.java`. That Activity currently references `file:///android_asset/www/index.html`, enables JavaScript/DOM storage, registers `AndroidBridge.showToast`, `AndroidBridge.vibrate`, and `AndroidBridge.getAppInfo`, and gives WebView history priority in `onBackPressed()`.
- The supplied page exists at `app/src/main/assets/www/schedule2.0.html`. It is a self-contained vanilla HTML/CSS/JavaScript Todo page with add, complete, and delete interactions, pink-to-blue styling, and calls to `AndroidBridge.showToast()` and `AndroidBridge.vibrate()`. It has no external asset or build-tool dependency. The Activity and layout are not yet aligned: the Activity looks up `R.id.webView`, while `activity_main.xml` currently contains only a “Hello World!” TextView; the Java package declaration (`com.example.todolist`) differs from the source folder and Gradle namespace (`com.example.lsysscheduleproject`).
- The Todo UI is now available for review. Preserve its existing file and UI; update the WebView entry URL to `schedule2.0.html` (or use an equivalent explicit asset mapping) rather than renaming or replacing the user's page.
- Confirmed exclusions: no login, no database or Azure datastore, no cloud API/backend, and no third-party web-to-APK packager. Keep the native host handwritten in this Android project.

---

## 2. TodoList Android App — Java Activity and local WebView host

| Component | Technology |
|-----------|-----------|
| **Language** | Java (native Android host); JavaScript (self-contained Todo page) |
| **Runtime** | Android (minSdk 24, targetSdk 37); Java source/target compatibility 11 |
| **Package Manager** | Gradle Wrapper 9.6.0 |
| **Test Runner** | JUnit 4.13.2 for local tests; AndroidX JUnit 1.1.5 and Espresso 3.5.1 for instrumented tests |
| **Mocking Library** | None currently present; do not add one unless implementation tests demonstrate a need |
| **Test Command** | `.\gradlew.bat testDebugUnitTest` and, with an available emulator/device, `.\gradlew.bat connectedDebugAndroidTest` |
| **Orchestration** | None; this is a local Android app with no containerized services |

**Host integration contract**:
- Continue the existing handwritten Java `MainActivity`; load `app/src/main/assets/www/schedule2.0.html` locally from `file:///android_asset/www/schedule2.0.html`. Keep the page's original UI, behavior, and vanilla web stack; do not substitute a newly designed Todo web UI.
- Keep the JavaScript bridge methods compatible with the page's `AndroidBridge.showToast(message)` and `AndroidBridge.vibrate(milliseconds)` calls. The page invokes them for empty/added/deleted/completed Todo feedback and vibration; the bridge is exposed only to this trusted local asset. Retain the existing vibration permission only if vibration remains enabled.
- Android Back must call `WebView.canGoBack()` / `WebView.goBack()` first and use normal Activity back behavior only when there is no WebView history.
- Correct the current Java package/namespace/activity resolution mismatch and replace the placeholder TextView layout with a layout containing the WebView before expecting the current Activity to run. Verify lifecycle cleanup and local asset loading.
- The Todo page is standalone HTML/CSS/JavaScript with inline styling and scripts, no frontend framework, package manager, external assets, or API routes. Todo state exists only in the page DOM; no database or durable persistence is currently implemented or requested.

---

## 3. Services Required

No Azure services are required for the confirmed local-only Android scope. The user confirmed no datastore; no “No datastore required” entry is represented as an Azure service.

| Azure Service | Role in App | Environment Variable | Default Value (Local) | Classification |
|---------------|------------|---------------------|----------------------|----------------|

---

## 4. Prerequisites

The current machine scan found the Android build/debug environment below. An installed marker confirms detection only; it does not mean the existing Java 8 command-line default is suitable for this Android Gradle Plugin. Use the detected Android Studio JBR (25.0.3) or another supported JDK for Gradle. The supplied HTML page has no separate frontend build step.

### Run

| Tool | Service(s) | Installed | Version |
|------|------------|-----------|---------|
| Android Studio bundled JDK / JDK | TodoList Android App | ✅ | Android Studio JBR 25.0.3 detected; command-line `java` is OpenJDK 8.0.482 |
| Android SDK | TodoList Android App | ✅ | Platform `android-37.0`; Build Tools `36.0.0` |
| Gradle Wrapper | TodoList Android App | ✅ | Wrapper configured and cached for Gradle 9.6.0 |
| Frontend package/build tool | TodoList Android App | ✅ | None; supplied page is standalone HTML/CSS/JavaScript |

### Debug

| Tool | Service(s) | Installed | Version |
|------|------------|-----------|---------|
| Android Studio | TodoList Android App | ✅ | Installation detected at `C:\Program Files\Android\Android Studio`; version not probed |
| Android Emulator | TodoList Android App | ✅ | Emulator 37.1.11.0; AVD `Medium_Phone` detected |

Double-check all ❓ items before proceeding. The existing command-line Java 8 is not the selected Gradle runtime; choose the detected Android Studio JBR 25.0.3 or another JDK supported by the project's Android Gradle Plugin.

---

## 5. Design System & UI

**Component Library**: Vanilla HTML/CSS/JavaScript (no component library; preserve the supplied page without adding a framework)
**Style Direction**: Preserve the existing playful Todo page: a soft pink-to-blue gradient background, translucent pink task panel, rounded task rows, and bright pink accents. Keep the page's existing compact add/complete/delete flow rather than redesigning it.
**Typography**: system-ui, sans-serif

### Color Palette

These tokens are sampled from the supplied Todo page and guide its planning preview; retain the original CSS in the Android asset.

| Token | Hex | Usage |
|-------|-----|-------|
| `primary` | `#FF8BBD` | Pink title and primary page accents |
| `accent` | `#F965B6` | Checkbox completion flower and delete/action accents |
| `surface` | `#EDF2F8` | Cool center tone of the page's pink-to-blue background gradient |
| `text` | `#FFFFFF` | Todo labels on the pink task rows |
| `muted` | `#FF96D1` | Subdued footer attribution |
| `border` | `#FFC2DE` | Translucent pink panel and rounded input boundaries |

### Pages

| Page | Route | Purpose | Layout |
|------|-------|---------|--------|
| Todo List | `/` | Add, complete, and delete personal tasks in the supplied local page | `header, form, list, actions, footer` |

### Sample Content

Todo List — task:

| Task | Completion |
|------|------------|
| eatting | Complete (as supplied in the existing page) |
| studying | Not complete |
| sleeping | Not complete |

The supplied page also has a free-text task input, an `add` action, per-row checkboxes and `del` actions, and the `/Danika's schedule/` footer. These sample rows are already present in the source; do not seed or persist additional tasks.

---

## 6. Project Structure

```text
project-root/
├── .azure/
│   ├── project-plan.md
│   └── .preview-temp/
│       ├── theme.css
│       ├── manifest.json
│       └── todo-list.html
├── app/
│   ├── build.gradle.kts
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/example/lsysscheduleproject/
│       │   │   └── MainActivity.java       # existing host; align declared package with namespace
│       │   ├── res/layout/activity_main.xml # replace placeholder with WebView host layout
│       │   └── assets/www/
│       │       └── schedule2.0.html        # supplied, self-contained Todo page
│       ├── test/java/com/example/lsysscheduleproject/
│       │   └── ...                         # host/bridge behavior tests
│       └── androidTest/java/com/example/lsysscheduleproject/
│           └── ...                         # WebView load, Back, and bridge integration tests
├── gradle/
│   └── wrapper/
└── gradlew.bat
```

The Todo HTML file is already present. The WebView layout and tests are planned changes; no asset-copy/build step is needed for this standalone page.

---

## 7. Route Definitions

This Android-only project has no HTTP API routes. The JavaScript bridge methods are local WebView-to-native calls, not REST endpoints; no `/api/health` endpoint is planned.

| # | Method | Path | Description | Request Body | Response Body | Status Codes |
|---|--------|------|-------------|-------------|--------------|-------------|

---

## 8. Next Steps

1. Review and approve this plan and its preview of the supplied Todo page.
2. After approval, implement the Android integration: align Activity package/namespace and layout, load the existing `schedule2.0.html`, verify local WebView load and Toast/vibration bridge behavior, and test Back-history priority and Activity lifecycle.
3. Validate with the Gradle wrapper and the detected Android emulator/device. No cloud infrastructure, database, API backend, or third-party web-to-APK packager is in scope.

**Approval gate**: Plan approved by the user. Proceed with the approved scaffold handoff.
