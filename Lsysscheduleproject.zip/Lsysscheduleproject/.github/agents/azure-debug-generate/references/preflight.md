<!-- azure-cor-disclaimer -->
> **Important:** This skill provides guidance and recommended instructions to assist the AI system. Outputs are not guaranteed to be complete, correct, secure, or applicable to every scenario. Results should be reviewed and validated by a human before being applied. The AI model may choose not to follow all instructions exactly, and additional verification may be required.

# Pre-Flight Checks

Before file generation, verify plan exists and environment ready.

## Container Runtime Readiness Check

Read the container runtime from the plan's Orchestrator table (**Docker**, **Podman**, or **Podman (Docker-compatible)**) and confirm the engine is actually running before you generate or validate anything. A CLI on PATH is not the same as a running engine.

- **Docker** — confirm the daemon is reachable (`docker info`). If it errors, tell the user to start Docker Desktop / the Docker service and wait, then retry.
- **Podman (Docker-compatible)** — the plan runs the Podman engine through its Docker-compatible socket, and the generated tasks use `docker compose`. Confirm the socket answers with `docker info` (it will report the Podman server). If `docker info` errors, the Docker-compatible socket isn't up: tell the user to enable Docker compatibility in Podman Desktop and ensure the **Podman machine** is started (same machine check as below), then retry.
- **Podman** — confirm the engine is reachable (`podman info`). On **Windows and macOS** this needs a running **Podman machine**:

  ```bash
  podman machine list --format '{{.Name}} {{.Running}}'
  ```

  - If a machine exists but is **stopped**, ask the user before starting it (starting a VM is a stateful, resource-consuming action):

    ```
    ask_user(
      question: "Your Podman machine \"podman-machine-default\" is stopped. Start it so the emulators can run?",
      choices: [
        "Yes, start the Podman machine",
        "No, I'll start it myself"
      ]
    )
    ```

    On approval, run `podman machine start` and wait for it to report ready.
  - If **no machine exists**, do NOT silently `podman machine init` — tell the user to run `podman machine init && podman machine start` (a one-time, multi-minute setup) and re-run once it is ready.

> ⛔ **NEVER switch the plan's container runtime on your own — not at readiness, not during generation, not during validation.** The runtime in the Orchestrator table was chosen (and, when the user asked for a specific engine, chosen *by them*). If the selected engine fails at **any** point — the engine won't start, a container won't come up, ports don't forward to the host, a volume/permission error, a health check never passes — **STOP and surface the blocker to the user with `ask_user`**, describing the failure and the options (fix the engine, or explicitly switch to the other engine). Do **not** silently rewrite the Orchestrator row, the `Start Emulators` task, or the convenience scripts to a different engine and continue. Silently falling back — e.g. from a user-requested Podman to Docker because Podman had a networking or bind-mount issue — is a **failure of this agent**, even if the resulting app works: the user asked for Podman and must decide, not discover after the fact that Docker ran everything.
>
> When you do surface a runtime blocker, prefer offering the **fix** first (many Podman-on-Windows issues are config, not dead ends — e.g. use the WSL machine provider for host port forwarding; database emulators must use a named volume, not a workspace bind mount, so `initdb` can `chown` its data dir). Only switch engines if the user explicitly chooses to.

## Stale Data Directory Check

Before generating files, find leftover emulator state from prior runs: **workspace data directories** (bind-mounted emulators such as Azurite's `.azurite/`, `.cosmos/`, `.servicebus/`) and **named volumes** (database emulators such as Postgres's `postgres_data`; see [emulators/postgres.md](emulators/postgres.md)). Stale state can break container startup; for example, PostgreSQL `initdb` refuses a `postgres_data` volume containing incompatible or partially initialized cluster files.

- **Bind-mounted data directories:** list via `ls`/`Get-ChildItem` in the workspace.
- **Named volumes:** list via `docker compose ls` / `docker volume ls` (or `podman` equivalents). A prior project's `*_postgres_data` volume is the database equivalent of a stale directory.

If any stale state is found:

1. **List all found directories and named volumes** with sizes.
2. **Ask how to proceed** via `ask_user`:

```
ask_user(
  question: "Leftover emulator state was found from a previous run:\n\n- .azurite/ (12 MB, workspace directory)\n- postgres_data (45 MB, named volume)\n\nThese can cause container startup failures. How would you like to handle this?",
  choices: [
    "Delete them and start fresh (recommended)",
    "Keep them — I want to preserve the existing data"
  ]
)
```

3. **If the user chooses to delete** — Before generation, remove bind-mounted directories using platform-appropriate removal (`rm -rf` on macOS/Linux, `Remove-Item -Recurse -Force` on Windows), and named volumes via `docker compose down -v` / `podman compose down -v` (or `docker volume rm <project>_postgres_data`).
4. **If the user wants to keep them** — Proceed with a container-start failure warning; offer cleanup if failure occurs.
5. **Never delete data directories or volumes silently** — Always confirm with the user first.

---

## Port Conflict Check

Before file generation, scan all planned emulator ports (e.g. `lsof -i -P -n`). Identify process name and PID per occupied port.

If any conflicts are found:

1. **List conflicts clearly** — port, process name, PID.
2. **Ask how to proceed** via `ask_user`:

```
ask_user(
  question: "The following ports are already in use on your machine:\n\n- Port 5432 → postgres (PID 1234)\n\nThese ports are needed by the planned emulators. How would you like to handle this?",
  choices: [
    "Help me remap the conflicting ports to alternatives",
    "I'll handle it myself — proceed with the plan as-is"
  ]
)
```

3. **If remapping help requested** — Propose alternatives; update every plan/project reference (docker-compose service ports, connection strings, convenience scripts, VS Code debug config); resume.
4. **If user handles it** — Generate with original ports.
5. **Never silently remap ports or modify config** — Confirm first.
