package com.example.lsysscheduleproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TODO_PAGE_URL =
            "file:///android_asset/www/schedule2.0.html";
    private static final String TODO_PAGE_PATH =
            "/android_asset/www/schedule2.0.html";

    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        initWebView();

        // Load the user's existing page directly from app assets.
        webView.loadUrl(TODO_PAGE_URL);
    }

    private void initWebView() {
        WebSettings settings = webView.getSettings();
        // 1. 开启 JS，否则前端页面跑不起来
        settings.setJavaScriptEnabled(true);
        // 2. 开启 DOM Storage，前端 localStorage 存 todolist 数据要靠它
        settings.setDomStorageEnabled(true);
        // Permit the local asset URL, but do not let file pages read other files
        // or make cross-origin requests.
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        // 4. 禁止缩放，避免页面像“网页”一样被双指缩放（更像 App）
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        // 5. 系统字体放大时不让网页排版乱掉
        settings.setTextZoom(100);

        // Keep navigation inside the trusted Todo asset only. In particular,
        // don't allow an untrusted page to inherit the JavaScript bridge.
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view, WebResourceRequest request) {
                return !isTodoAssetUrl(request.getUrl());
            }

            @SuppressWarnings("deprecation")            }
        });

        // 支持网页里的 alert / confirm
        webView.setWebChromeClient(new WebChromeClient());

        // 注册 JS 接口：网页里通过 window.AndroidBridge 调用
        webView.addJavascriptInterface(new JsBridge(), "AndroidBridge");
    }

    private boolean isTodoAssetUrl(Uri uri) {
        return "file".equals(uri.getScheme())
                && (uri.getAuthority() == null || uri.getAuthority().isEmpty())
                && TODO_PAGE_PATH.equals(uri.getPath());
    }

    /**
     * 暴露给网页的原生能力。
     * 注意：这些方法运行在 WebView 的 JavaBridge 线程，不是主线程，
     * 所以更新 UI（Toast）必须 runOnUiThread。
     */
    public class JsBridge {

        @JavascriptInterface
        public void showToast(String message) {
            runOnUiThread(() ->
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void vibrate(long milliseconds) {
            if (milliseconds <= 0) return;

            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;

            long duration = Math.min(milliseconds, 10_000L);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(
                        duration, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(duration); // Compatible with Android versions below 8.0.
            }
        }

        @JavascriptInterface
        public String getAppInfo() {
            return "Android " + Build.VERSION.RELEASE;
        }
    }

    /** 返回键：网页能后退就后退，否则退出 App */
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // 让 WebView 跟随 Activity 生命周期，避免后台继续跑 JS 消耗资源
    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}