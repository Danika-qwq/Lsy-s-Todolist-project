package com.example.lsysscheduleproject;

import android.content.Context;
import android.content.Intent;
import android.webkit.WebView;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.Assert.*;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    private MainActivity activity;

    @After
    public void closeActivity() {
        if (activity != null) {
            InstrumentationRegistry.getInstrumentation().runOnMainSync(activity::finish);
        }
    }

    @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.example.lsysscheduleproject", appContext.getPackageName());
    }

    @Test
    public void loadsLocalPageAndBackNavigatesWebViewHistoryFirst() throws Exception {
        android.app.Instrumentation instrumentation =
                InstrumentationRegistry.getInstrumentation();
        Intent intent = new Intent(instrumentation.getTargetContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity = (MainActivity) instrumentation.startActivitySync(intent);

        WebView webView = activity.findViewById(R.id.webView);
        assertNotNull("The Activity layout must contain its WebView", webView);
        AtomicReference<String> loadedUrl = new AtomicReference<>();
        instrumentation.runOnMainSync(() -> loadedUrl.set(webView.getUrl()));
        assertEquals("file:///android_asset/www/schedule2.0.html", loadedUrl.get());

        String pageReady = "waiting";
        long pageLoadDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
        while (!"\"ready\"".equals(pageReady) && System.nanoTime() < pageLoadDeadline) {
            pageReady = evaluateJavascript(
                    webView,
                    "document.readyState === 'complete' && document.title === '日程表' "
                            + "&& typeof AndroidBridge.showToast === 'function' "
                            + "&& typeof AndroidBridge.vibrate === 'function' ? 'ready' : 'waiting'");
            if (!"\"ready\"".equals(pageReady)) {
                Thread.sleep(50);
            }
        }
        assertEquals("\"ready\"", pageReady);

        String imeInputResult = evaluateJavascript(webView,
                "(function() {"
                        + "const input = document.querySelector('.input');"
                        + "const list = document.getElementById('todoList');"
                        + "const initialCount = list.children.length;"
                        + "input.value = '中文待办';"
                        + "input.dispatchEvent(new KeyboardEvent('keydown', {"
                        + "key: 'Enter', keyCode: 229, isComposing: true, bubbles: true"
                        + "}));"
                        + "const compositionPreserved = input.value === '中文待办'"
                        + " && list.children.length === initialCount;"
                        + "input.dispatchEvent(new KeyboardEvent('keydown', {"
                        + "key: 'Enter', bubbles: true"
                        + "}));"
                        + "return compositionPreserved"
                        + " && input.value === ''"
                        + " && list.children.length === initialCount + 1"
                        + " && list.lastElementChild.querySelector('.things').textContent"
                        + " === '中文待办' ? 'passed' : 'failed';"
                        + "})()");
        assertEquals("Chinese IME confirmation should preserve text; normal Enter should add it",
                "\"passed\"", imeInputResult);

        instrumentation.runOnMainSync(() ->
                webView.loadUrl("file:///android_asset/www/schedule2.0.html?history=1"));
        long historyDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
        AtomicReference<String> historyUrl = new AtomicReference<>();
        while (System.nanoTime() < historyDeadline) {
            instrumentation.runOnMainSync(() -> historyUrl.set(webView.getUrl()));
            if (historyUrl.get() != null && historyUrl.get().contains("?history=1")) {
                break;
            }
            Thread.sleep(50);
        }
        assertEquals("file:///android_asset/www/schedule2.0.html?history=1", historyUrl.get());

        AtomicReference<Boolean> canGoBack = new AtomicReference<>();
        historyDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
        while (System.nanoTime() < historyDeadline) {
            instrumentation.runOnMainSync(() -> canGoBack.set(webView.canGoBack()));
            if (Boolean.TRUE.equals(canGoBack.get())) {
                break;
            }
            Thread.sleep(50);
        }
        assertTrue("Loading a second local-page entry should create WebView history",
                canGoBack.get());

        instrumentation.runOnMainSync(activity::onBackPressed);
        long backDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
        AtomicReference<String> backUrl = new AtomicReference<>();
        while (System.nanoTime() < backDeadline) {
            instrumentation.runOnMainSync(() -> backUrl.set(webView.getUrl()));
            if ("file:///android_asset/www/schedule2.0.html".equals(backUrl.get())) {
                break;
            }
            Thread.sleep(50);
        }
        assertEquals("file:///android_asset/www/schedule2.0.html", backUrl.get());
        assertFalse("Back should remain in the Activity while WebView has history",
                activity.isFinishing());
    }

    private String evaluateJavascript(WebView webView, String expression) throws Exception {
        CountDownLatch resultReady = new CountDownLatch(1);
        AtomicReference<String> result = new AtomicReference<>();
        instrumentationRunOnMain(() -> webView.evaluateJavascript(expression, value -> {
            result.set(value);
            resultReady.countDown();
        }));
        assertTrue("Timed out waiting for WebView JavaScript",
                resultReady.await(10, TimeUnit.SECONDS));
        return result.get();
    }

    private void instrumentationRunOnMain(Runnable action) {
        InstrumentationRegistry.getInstrumentation().runOnMainSync(action);
    }
}